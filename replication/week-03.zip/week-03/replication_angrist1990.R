# ============================================================
# Angrist (1990) — Script de replicación
# ECO-60116: Inferencia, Causalidad y Políticas Públicas
# Universidad Icesi — Eduard F. Martinez Gonzalez, Ph.D.
#
# Cubre:
#   Tabla 1: Balance en covariables (chequeo de independencia de Z)
#   Tabla 2: Primera etapa
#   Tabla 3: Reduced form, OLS e IV (2SLS)
#   Diagnósticos: F de primera etapa, Wu-Hausman, Sargan
#
# Paquetes requeridos: AER, fixest, modelsummary
# ============================================================

# ------------------------------------------------------------
# 0. Setup
# ------------------------------------------------------------

# clean environment
rm(list=ls())

# library
library(AER)          # ivreg()
library(fixest)       # feols() con sintaxis IV
library(modelsummary) # tablas comparables

# Cargar datos (generados con 01_generate_data.R)
df <- readRDS("data/angrist1990_data.rds")

# ============================================================
# TABLA 1: Balance en covariables
# ============================================================
# Verificar que Z (eligible) es independiente de características
# predeterminadas (raza, cohorte). Si Z es aleatorio, no debe
# predecir estas variables.

# Regresión de cada covariable sobre el instrumento
bal_white  <- lm(white  ~ eligible, data = df)
bal_cohort <- lm(cohort ~ eligible, data = df)

# Mostrar coeficientes sobre eligible
modelsummary(list("Blanco (white)"=bal_white , "Cohorte"=bal_cohort),
             coef_map   = c("eligible" = "Draft-eligible (Z)"),
             statistic  = "({std.error})",
             stars      = c("*" = 0.10, "**" = 0.05, "***" = 0.01),
             gof_map    = c("nobs", "r.squared"),
             title      = "Tabla 1. Balance en covariables predeterminadas",
             notes      = "Errores estándar en paréntesis. Si Z es aleatorio, el coeficiente debe ser ~0.",
             #output    = "output/tabla1_balance.txt"
)

# Mensaje de interpretación: Si eligible no predice white ni cohort, el instrumento está balanceado.
# Esto apoya el supuesto de independencia: Z _|_ U.

# ============================================================
# TABLA 2: Primera etapa
# ============================================================
# D_i = pi0 + pi1*Z_i + controles + nu_i
# Objetivo: pi1 significativo y F > 10

# Sin controles
fs1 <- lm(veteran ~ eligible, data = df)

# Con controles (raza y cohorte)
fs2 <- lm(veteran ~ eligible + white + factor(cohort), data = df)

## tabla comparativa
modelsummary(list("Sin controles"=fs1 , "Con controles"=fs2),
            coef_map   = c("eligible" = "Draft-eligible (Z)",
                           "white" = "Blanco",
                           "factor(cohort)1951" = "Cohorte 1951",
                           "factor(cohort)1952" = "Cohorte 1952",
                           "factor(cohort)1953" = "Cohorte 1953"),
            statistic  = "({std.error})",
            stars      = c("*" = 0.10, "**" = 0.05, "***" = 0.01),
            gof_map    = c("nobs", "r.squared", "statistic.Weak.instrument"),
            title      = "Tabla 2. Primera etapa: efecto del instrumento sobre el servicio militar",
            notes      = "Variable dependiente: veteran (=1 si sirvió en Vietnam). Errores estándar en paréntesis.",
            #output     = "output/tabla2_primera_etapa.txt"
)

# F-statistic manual
f_stat <- summary(fs2)$fstatistic
f_stat

# ============================================================
# ESTIMADOR DE WALD (manual)
# ============================================================

## media de Y condicionada en Z
mean_Y1 <- mean(df$earn[df$eligible == 1])
mean_Y0 <- mean(df$earn[df$eligible == 0])

## media de D condicionada en Z
mean_D1 <- mean(df$veteran[df$eligible == 1])
mean_D0 <- mean(df$veteran[df$eligible == 0])

## ITT 
reduced_form <- mean_Y1 - mean_Y0
reduced_form

## Relevancia del Instrumento
first_stage <- mean_D1 - mean_D0
first_stage

## Estimador de Wald
wald <- reduced_form / first_stage
wald

## Interpretación: el servicio militar redujo los ingresos de los compliers en aproximadamente:
paste0(round(abs(wald)*100,2),"%")

# ============================================================
# TABLA 3: Reduced form, OLS e IV (2SLS)
# ============================================================
cat("\n=== TABLA 3: Reduced form, OLS e IV ===\n")

# Reduced form: Y sobre Z
rf_model  <- lm(earn ~ eligible + white + factor(cohort), data = df)
summary(rf_model)

# OLS (sesgado): Y sobre D directamente
ols_model <- lm(earn ~ veteran  + white + factor(cohort), data = df)
summary(ols_model)

# IV con AER::ivreg()
iv_aer    <- ivreg(earn ~ veteran + white + factor(cohort) |
                          eligible + white + factor(cohort),
                   data = df)
summary(iv_aer)

# IV con fixest::feols()
iv_fixest <- feols(earn ~ white + i(cohort) | veteran ~ eligible,
                   data = df, vcov = "hetero")
summary(iv_fixest)

## tabla comparativa
modelsummary(list("Reduced form" = rf_model,
                 "OLS" = ols_model,
                 "IV (ivreg)" = iv_aer,
                 "IV (feols)" = iv_fixest),
             coef_map = c("eligible" = "Draft-eligible (Z)", 
                          "veteran" = "Veterano (D)",
                          "fit_veteran" = "Veterano (D)",
                          "white" = "Blanco"),
             statistic = "({std.error})",
             stars = c("*" = 0.10, "**" = 0.05, "***" = 0.01),
             gof_map = c("nobs", "r.squared"),
             title = "Tabla 3. Reduced form, OLS e IV: efecto del servicio militar sobre log(earnings)",
             notes = paste0("Variable dependiente: log(earnings anuales). ",
                                "Controles: raza y cohorte. ",
                                "Errores estándar en paréntesis. ",
                                "OLS es sesgado hacia arriba por selección positiva. ",
                                "IV identifica el LATE sobre los compliers."),
             #output = "output/tabla3_resultados.txt"
)


