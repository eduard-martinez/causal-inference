# =============================================================================
#   Replicacion en R de las Tablas 1 y 2 del paper:
#
#   Duflo, Esther; Hanna, Rema; Ryan, Stephen P. (2012)
#   "Incentives Work: Getting Teachers to Come to School"
#   American Economic Review 102(4): 1241-1278.
#
# =============================================================================

# Instalar si es necesario:
#install.packages(c("haven","dplyr","tidyr","readr","fixest","broom"))

# llamar librerias
library(haven)    # leer archivos .dta
library(dplyr)    # manipulacion de datos
library(tidyr)    # reshape
library(readr)    # leer cameras.txt
library(fixest)   # regresiones con SE robustos/clusterizados
library(broom)    # tidy() para salidas de regresion

# =============================================================================
# LIMPIEZA DEL DATASET RANDOMCHECK (replica Table1_Fig1_update.do)
# =============================================================================

# randomcheck.dta: registro de las visitas sorpresa mensuales a cada escuela
#                  (una observacion por escuela-visita). Variables principales:
#   schid          : identificador unico de la escuela (cluster)
#   treat          : 1 = escuela tratada (camara + bono), 0 = control
#   year, month, day : fecha de la visita sorpresa
#   open           : 1 si la escuela estaba abierta (profesor presente), 0 si cerrada
#   students       : numero de ninos presentes en el aula durante la visita
#   inside         : fraccion de ninos sentados dentro del salon de clase
#   bbused         : 1 si el tablero fue usado (hay contenido escrito), 0 si no
#   interact_kids  : 1 si el profesor estaba interactuando con los estudiantes

# load data
rc <- read_dta("Raw-Data/RandomCheck/Teacher-Attendance/randomcheck.dta")

# Recodificacion de fecha a variable "time" (1..31 = ago/2003..feb/2006)
# Se construye una linea de tiempo mensual continua para facilitar filtros
# por ventanas temporales (linea base, pre-midtest, post-midtest, etc.).
date_map <- c(`2003-8`=1, `2003-9`=2, `2003-10`=3, `2003-11`=4, `2003-12`=5,
              `2004-1`=6, `2004-2`=7, `2004-3`=8, `2004-4`=9, `2004-5`=10,
              `2004-6`=11, `2004-7`=12, `2004-8`=13, `2004-9`=14, `2004-10`=15,
              `2004-11`=16, `2004-12`=17,
              `2005-1`=18, `2005-2`=19, `2005-3`=20, `2005-4`=21, `2005-5`=22,
              `2005-6`=23, `2005-7`=24, `2005-8`=25, `2005-9`=26, `2005-10`=27,
              `2005-11`=28, `2005-12`=29,
              `2006-1`=30, `2006-2`=31)

## prepare data
rc <- rc %>%
      mutate(key = paste(year, month, sep = "-") , time = date_map[key]) %>%
      # Reasignar escuelas visitadas el 25 de agosto a septiembre
      # (el programa se anuncio el 25 de agosto; las visitas posteriores
      #  ya reflejan el efecto del tratamiento)
      mutate(time = ifelse(month == 8 & day > 24, 2, time)) %>%
      # Escuelas excluidas en el paper (cierres tempranos no relacionados
      # con el programa; ver nota al pie 6 del paper)
      filter(!schid %in% c(1111, 1211, 2493, 5221, 5231, 5332, 5711)) %>%
      select(-key)

# =============================================================================
# TABLA 1 - Balance en caracteristicas de linea base (time == 1)
# =============================================================================
# Objetivo: mostrar que tratamiento y control eran estadisticamente
# indistinguibles ANTES de la intervencion. Es el chequeo empirico de
# la aleatorizacion.

# Panel A: tasa de asistencia del profesor (open) en t=1
# Pregunta: la probabilidad de encontrar la escuela abierta en la
# visita de linea base es similar entre tratamiento y control?
t1_df <- rc %>% filter(time == 1)

panelA <- t1_df %>%
          group_by(treat) %>%
          summarise(mean_open = mean(open, na.rm = TRUE),    # tasa de asistencia
                    n = sum(!is.na(open)), .groups = "drop") # n de escuelas

regA <- lm(open ~ treat, data = t1_df)  # diferencia de medias con SE

# Panel B/D: caracteristicas cuando la escuela esta abierta
# Solo se calculan en escuelas abiertas porque las variables de
# comportamiento docente (students, inside, bbused, interact_kids)
# solo se observan si el profesor esta presente.
t1_open <- rc %>% filter(time == 1, open == 1)

panelBD <- t1_open %>%
  group_by(treat) %>%
  summarise(students = mean(students, na.rm = TRUE),           # ninos presentes
            inside = mean(inside, na.rm = TRUE),               # % sentados adentro
            bbused = mean(bbused, na.rm = TRUE),               # uso del tablero
            interact_kids = mean(interact_kids, na.rm = TRUE), # interaccion docente
            .groups = "drop")

reg_students <- lm(students      ~ treat, data = t1_open)
reg_inside   <- lm(inside        ~ treat, data = t1_open)
reg_bbused   <- lm(bbused        ~ treat, data = t1_open)
reg_interact <- lm(interact_kids ~ treat, data = t1_open)

# Panel C: puntaje del teacher test
# teacher_test.dta: prueba de competencias administrada a cada profesor
# ANTES del programa. Un registro por escuela (schid), ya que cada NFE
# tiene un solo docente. Variables de subsecciones:
#   comp1, comp2, comp3 : secciones de comprension lectora
#   clozet              : prueba de cloze (completar texto)
#   story               : comprension de historia
#   attitude            : actitudes hacia la ensenanza
#   nnc1, nc1, nc2,     : secciones de matematicas y numeracion
#   nnc2, nnc3, nc3
#   vp                  : vocabulario pasivo
#   map                 : lectura de mapas/orientacion espacial
# score = suma de todas las subsecciones = competencia global del docente

# load data
tt <- read_dta("Raw-Data/RandomCheck/Teacher-Attendance/teacher_test.dta") %>%
      mutate(score = comp1 + comp2 + comp3 + clozet + story + attitude +
               nnc1 + nc1 + nc2 + nnc2 + nnc3 + nc3 + vp + map) %>%
      select(schid, score)

# Unir con randomcheck para asignar tratamiento a cada docente
panelC <- rc %>%
          distinct(schid, treat) %>%      # una fila por escuela
          inner_join(tt, by = "schid") %>%
          filter(!is.na(score))

panelC_means <- panelC %>%
                group_by(treat) %>%
                summarise(mean_score = mean(score), n = n(), .groups = "drop")

regC <- lm(score ~ treat, data = panelC)

# =============================================================================
#    TABLA 2 - Efecto del tratamiento sobre la asistencia (ITT)
#    Replica Table-2.do con errores estandar clusterizados por escuela (schid)
# =============================================================================
# Intent-To-Treat: efecto de haber sido ASIGNADO al tratamiento, sin
# condicionar en cumplimiento. En este experimento compliance es casi
# perfecta (todas las escuelas tratadas recibieron camara), asi que
# ITT ~ ATE.
# SE clusterizados por schid: las observaciones de la misma escuela
# en distintas visitas estan correlacionadas (mismo docente).

# Quitar observaciones de linea base (t=1): solo se evalua el efecto
# en el periodo POSTERIOR a la implementacion del programa.
rc_post <- rc %>% filter(time != 1)

# Columnas 1-4: toda la muestra en distintas ventanas de tiempo
# Ventanas definidas por los hitos de evaluacion del paper:
#   time < 9   -> pre-midtest (sep 2003 - mar 2004)
#   9<time<16  -> midtest a posttest (abr 2004 - oct 2004)
#   time > 15  -> post-posttest (nov 2004 - feb 2006); periodo sin evaluacion formal
m2_1 <- feols(open ~ treat, data = rc_post, cluster = ~schid) # muestra completa
m2_2 <- feols(open ~ treat, data = filter(rc_post, time < 9), cluster = ~schid)  # hasta midtest
m2_3 <- feols(open ~ treat, data = filter(rc_post, time > 8 & time < 16),        cluster = ~schid)  # midtest-posttest
m2_4 <- feols(open ~ treat, data = filter(rc_post, time > 15), cluster = ~schid)  # post-posttest

# Heterogeneidad por calidad del docente (score mediana)
# above_score = 1 si el docente esta en el top 50% de la prueba pre-programa.
# Permite preguntar: el efecto del programa depende de la calidad inicial
# del docente? (Respuesta del paper: el efecto es mas fuerte en docentes
# de menor calidad, pues partian de asistencia mas baja.) 
rc_score <- rc %>%
            distinct(schid, treat) %>%
            inner_join(tt, by = "schid") %>%
            filter(!is.na(score)) %>%
            mutate(above_score = as.integer(score >= median(score, na.rm = TRUE))) %>%
            select(schid, above_score)

rc_post_h <- rc_post %>% inner_join(rc_score, by = "schid")

# Columnas 5-8: escuelas con score por encima de la mediana
m2_5 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 1), cluster = ~schid)
m2_6 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 1, time < 9), cluster = ~schid)
m2_7 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 1, time > 8 & time < 16), cluster = ~schid)
m2_8 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 1, time > 15), cluster = ~schid)

# Columnas 9-12: escuelas con score por debajo de la mediana
m2_9  <- feols(open ~ treat, data = filter(rc_post_h, above_score == 0), cluster = ~schid)
m2_10 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 0, time < 9), cluster = ~schid)
m2_11 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 0, time > 8 & time < 16), cluster = ~schid)
m2_12 <- feols(open ~ treat, data = filter(rc_post_h, above_score == 0, time > 15), cluster = ~schid)



