# ============================================================
# DiD: el mismo estimador por tres caminos + generalización a
#      muchos períodos
# ECO-60116: Inferencia, Causalidad y Políticas Públicas
# Universidad Icesi — Eduard F. Martinez Gonzalez, Ph.D.
#
# Lo que se ilustra:
#   PARTE 1 — Base de 2 períodos (estilo Card & Krueger):
#     (a) DiD "a mano" con la tabla 2x2 de medias.
#     (b) Regresión con términos treated y post (fte ~ nj * d).
#     (c) Two-way fixed effects (fte ~ nj:d | id + d).
#     Verificación: (a) = (b) = (c), idénticos bit a bit.
#
#   PARTE 2 — Panel con MUCHOS períodos pre y post:
#     (d) Se repite el trío (a)-(b)-(c) colapsando a pre/post.
#     (e) Generalización: TWFE con TODOS los períodos
#         (y ~ D | id + t) recupera el ATT verdadero.
#
# DATOS: las dos bases las produce 'generate_data_did.R' (correr
#   ese script primero). Son sintéticas y balanceadas, con efecto
#   verdadero conocido: ATT = +2.75 (Base 1) y ATT = +5 (Base 2).
# ------------------------------------------------------------
# Autor de la replicación en R: Claude y Eduard Martinez (2026)
# ============================================================
rm(list = ls())

# ------------------------------------------------------------
# 0. Setup
# ------------------------------------------------------------
library(tidyverse)   # manipulación de datos y ggplot2
library(fixest)      # feols(): DiD, TWFE y SE clusterizados

# ============================================================
# PARTE 1 — TRES CAMINOS, UN MISMO ESTIMADOR (2 períodos)
# ============================================================
njmin <- read_csv("simulacion_did_2periodos.csv", show_col_types = FALSE)
# Variables: id (restaurante), nj (1=tratado), d (1=post), fte (outcome).
# La base ya viene balanceada y completa: por eso los tres caminos
# coinciden de forma exacta (el TWFE de id solo usa unidades con dos obs).

# ------------------------------------------------------------
# (a) DiD A MANO: tabla 2x2 de medias
# ------------------------------------------------------------
cat("================= (a) DiD a mano (tabla 2x2) =================\n")
celdas <- njmin %>%
  group_by(nj, d) %>%
  summarise(mean_fte = mean(fte), .groups = "drop")
print(celdas)

m <- function(nj_, d_) celdas$mean_fte[celdas$nj == nj_ & celdas$d == d_]
delta_nj <- m(1,1) - m(1,0)            # cambio en el grupo tratado (NJ)
delta_pa <- m(0,1) - m(0,0)            # cambio en el grupo control (PA)
did_manual <- delta_nj - delta_pa      # doble diferencia

cat(sprintf("\nDelta NJ = %+.4f ; Delta PA = %+.4f\n", delta_nj, delta_pa))
cat(sprintf("DiD (a mano) = %+.4f\n\n", did_manual))

# ------------------------------------------------------------
# (b) REGRESIÓN con treated, post y su interacción
#     fte = a + g*nj + l*d + delta*(nj*d) + e ; delta = DiD
# ------------------------------------------------------------
m_dummies   <- feols(fte ~ nj * d, data = njmin)
did_dummies <- coef(m_dummies)["nj:d"]

# ------------------------------------------------------------
# (c) TWO-WAY FIXED EFFECTS
#     El FE de id absorbe nj (fijo en el tiempo); el FE de d
#     absorbe el efecto post. Queda identificada la interacción.
# ------------------------------------------------------------
m_twfe   <- feols(fte ~ nj:d | id + d, data = njmin)
did_twfe <- coef(m_twfe)["nj:d"]

# ------------------------------------------------------------
# VERIFICACIÓN: los tres caminos dan el MISMO número
# ------------------------------------------------------------
cat("=========== VERIFICACIÓN: (a) = (b) = (c) ===========\n")
equivalencia1 <- c("(a) a mano"        = did_manual,
                   "(b) nj*d"          = unname(did_dummies),
                   "(c) TWFE |id+d"    = unname(did_twfe))
print(round(equivalencia1, 6))
cat(sprintf("\n¿Idénticos? %s   (ATT verdadero = 2.75)\n\n",
            isTRUE(all.equal(did_manual, unname(did_dummies))) &&
            isTRUE(all.equal(did_manual, unname(did_twfe)))))

# ============================================================
# PARTE 2 — GENERALIZACIÓN A MUCHOS PERÍODOS
# ============================================================
panel <- read_csv("simulacion_did_multiperiodo.csv", show_col_types = FALSE) %>%
  mutate(D = treat * post)              # tratamiento activo (treat AND post)
# Variables: id, t (1..12), treat (1=grupo tratado), post (1 si t>=7), y.

t_star <- 7
cat(sprintf("================= Panel: %d unidades x %d períodos =================\n",
            n_distinct(panel$id), n_distinct(panel$t)))
cat(sprintf(">>> %d períodos pre y %d post; ATT verdadero = 5\n\n",
            t_star - 1, max(panel$t) - t_star + 1))

# ------------------------------------------------------------
# (d) EL MISMO TRÍO, colapsando a pre/post
#     'post' agrupa todos los períodos pre y todos los post.
# ------------------------------------------------------------
cat("=========== (d) El trío de nuevo (colapsado a pre/post) ===========\n")
celdas2 <- panel %>%
  group_by(treat, post) %>%
  summarise(mean_y = mean(y), .groups = "drop")

g <- function(tr, po) celdas2$mean_y[celdas2$treat == tr & celdas2$post == po]
did2_manual  <- (g(1,1) - g(1,0)) - (g(0,1) - g(0,0))            # 2x2 a mano
did2_dummies <- coef(feols(y ~ treat * post, data = panel))["treat:post"]
did2_twfe    <- coef(feols(y ~ treat:post | id + post, data = panel))["treat:post"]

equivalencia2 <- c("(a) a mano"        = did2_manual,
                   "(b) treat*post"    = unname(did2_dummies),
                   "(c) TWFE |id+post" = unname(did2_twfe))
print(round(equivalencia2, 6))
cat("\n")

# ------------------------------------------------------------
# (e) GENERALIZACIÓN: TWFE con TODOS los períodos
#     Usa los 12 FE de tiempo (no solo pre/post). Es la versión
#     que escala a paneles largos: más eficiente y recupera el ATT.
# ------------------------------------------------------------
cat("=========== (e) TWFE con todos los períodos (la generalización) ===========\n")
m_twfe_full <- feols(y ~ D | id + t, data = panel, cluster = ~ id)
print(summary(m_twfe_full))

cat(sprintf("\nATT verdadero          = %.3f\n", 5))
cat(sprintf("TWFE colapsado (d)     = %.3f\n", did2_twfe))
cat(sprintf("TWFE multi-período (e) = %.3f  <- usa todos los períodos\n\n",
            coef(m_twfe_full)["D"]))
# (d) y (e) apuntan al mismo ATT; coinciden en expectativa.
# (e) es más eficiente porque aprovecha la variación de cada período.

# ------------------------------------------------------------
# 2.1 Figura: medias por período (tratados vs control)
# ------------------------------------------------------------
fig_panel <- panel %>%
  group_by(treat, t) %>%
  summarise(mean_y = mean(y), .groups = "drop") %>%
  mutate(Grupo = factor(treat, levels = c(0,1),
                        labels = c("Control","Tratado")))

p2 <- ggplot(fig_panel, aes(t, mean_y, color = Grupo)) +
  geom_vline(xintercept = t_star - 0.5, linetype = "dashed", color = "grey50") +
  annotate("text", x = t_star - 0.5, y = max(fig_panel$mean_y),
           label = "adopción", hjust = -0.1, vjust = 1, size = 3, color = "grey40") +
  geom_line(linewidth = 1) + geom_point(size = 2) +
  labs(title = "DiD con muchos períodos",
       subtitle = "Tendencias paralelas en el pre; brecha que se abre tras la adopción",
       x = "Período (t)", y = "y promedio", color = NULL) +
  theme_minimal(base_size = 13) + theme(legend.position = "bottom")

print(p2)
ggsave("fig_did_multiperiodo.png", p2, width = 7, height = 4.5, dpi = 300)
cat(">>> Figura guardada en: fig_did_multiperiodo.png\n")

# ============================================================
# CIERRE — Preguntas de discusión
# ============================================================
# 1. En la Parte 1, ¿por qué los tres caminos dan EXACTAMENTE el
#    mismo número? ¿Qué papel juega que la base esté balanceada?
# 2. ¿Qué pasaría si borráramos una de las dos rondas de algunos
#    restaurantes (panel desbalanceado)? ¿Cuál estimador cambia?
# 3. En la Parte 2, ¿por qué (d) y (e) no son bit-idénticos pero sí
#    cercanos? ¿Cuál tiene menor error estándar? ¿Por qué?
# 4. Suba el ruido (sd del error en el generador) y compare el SE
#    de (e). ¿Qué tan robusta es la recuperación del ATT?
# 5. La adopción aquí es en una fecha COMÚN. ¿Qué cree que pasa con
#    el TWFE si distintas unidades adoptan en momentos distintos?
#    (Ese es el tema de la próxima semana: adopción escalonada.)
# ============================================================
