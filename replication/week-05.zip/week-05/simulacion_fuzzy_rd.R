# ============================================================
# Pop-Eleches & Urquiola (2013) — Simulación Fuzzy RD
# ECO-60116: Inferencia, Causalidad y Políticas Públicas
# Universidad Icesi — Eduard F. Martinez Gonzalez, Ph.D.
#
# Datos: simulación inspirada en el diseño de Pop-Eleches &
#   Urquiola (2013). Cada observación es un par estudiante–liceo
#   s. El verdadero τ_LATE = 0.60 está incorporado en el DGP.
#
# Variables:
#   x  : puntaje de transición menos cutoff del liceo s
#        (running variable centrada en 0)
#   z  : 1{x >= 0} — indicador de cruce del umbral
#   d  : 1 si el estudiante asiste al liceo "mejor"
#        (cruzar z sube Pr(D=1) en ~50 pp)
#   y  : nota en el Baccalaureate (estandarizada)
#   w1 : covariable predeterminada continua (p. ej., nota previa)
#   w2 : covariable predeterminada binaria  (p. ej., estrato)
#
# Resultados que se replican:
#   Figura 1   : rdplot(d ~ x)  — primera etapa
#   Figura 2   : rdplot(y ~ x)  — forma reducida
#   Tabla 1    : Estadísticas descriptivas y balance por lado
#                del umbral (t-test)
#   Tabla 2    : Primera etapa — rdrobust(d ~ x), 3 anchos de banda
#   Tabla 3    : Forma reducida (ITT) vs. Fuzzy RD (LATE)
#   Validación (A) : Prueba de densidad McCrary (rddensity)
#   Validación (B) : Cutoffs placebo en c = −0.3 y c = +0.3
#   Validación (C) : Matriz de sensibilidad {h*/2, h*, 2h*} × {p=1, p=2}
# ============================================================

# ------------------------------------------------------------
# 0. Setup
# ------------------------------------------------------------
rm(list = ls())

# Paquetes
library(tidyverse)     # manipulación de datos y ggplot2
library(rdrobust)      # rdrobust(), rdplot(), rdbwselect()
library(rddensity)     # rddensity() — prueba de manipulación McCrary
library(modelsummary)  # tablas de resultados

# Cargar datos
df <- read_csv("simulacion_Pop-Eleches_Urquiola.csv")

# Vistazo rápido
glimpse(df)

## Distribución de la running variable (debe ser suave en c = 0)
plot(density(df$x),
     main = "Densidad de la running variable",
     xlab = "X (puntaje − cutoff)")
abline(v = 0, lty = 2, col = "gray50")

## Tabla cruzada Z × D: ¿cuántos tratados a cada lado del umbral?
cat("\n--- Tabla cruzada Z x D ---\n")
print(table(Z = df$z, D = df$d))
cat("\nProporción de tratados por lado del umbral:\n")
print(round(prop.table(table(Z = df$z, D = df$d), margin = 1), 3))
# Interpretación: la diferencia en la proporción de D=1 entre Z=1 y Z=0
# es la primera etapa "no paramétrica". En el paper es ~40–50 pp.


# ============================================================
# FIGURA 1: PRIMERA ETAPA — rdplot(d ~ x)
# ============================================================
# El salto vertical en c = 0 muestra que cruzar el umbral
# aumenta la probabilidad de asistir al liceo "mejor".
# En Sharp RD este salto sería de 0 a 1; en Fuzzy es parcial.

rdplot(y        = df$d,
       x        = df$x,
       c        = 0,
       p        = 1,
       title    = "Figura 1. Primera etapa: Pr(D = 1 | X)",
       x.label  = "X (puntaje − cutoff)",
       y.label  = "Pr(D = 1)",
       col.dots  = "navy",
       col.lines = "maroon")
# Interpretación: el salto visible en c = 0 confirma que el umbral
# genera variación real en el tratamiento — la primera etapa existe.


# ============================================================
# FIGURA 2: FORMA REDUCIDA — rdplot(y ~ x)
# ============================================================
# El salto en c = 0 es el efecto del instrumento Z sobre Y
# (intent-to-treat, ITT). Para obtener el efecto del tratamiento
# efectivo se divide por la primera etapa (estimador Wald local).

rdplot(y        = df$y,
       x        = df$x,
       c        = 0,
       p        = 1,
       title    = "Figura 2. Forma reducida: E[Y | X]",
       x.label  = "X (puntaje − cutoff)",
       y.label  = "Y (Baccalaureate, estandarizado)",
       col.dots  = "navy",
       col.lines = "maroon")
# Interpretación: el salto en Y en el umbral es el ITT. Si la primera
# etapa también salta, el cociente es el LATE sobre los compliers.


# ============================================================
# TABLA 1: ESTADÍSTICAS DESCRIPTIVAS Y BALANCE
# ============================================================
# w1 y w2 son covariables predeterminadas (medidas antes del
# tratamiento). Bajo continuidad NO deben saltar en c = 0.
# Reportamos medias por lado del umbral y un t-test de diferencias.

vars_desc <- c("y",   # outcome principal
               "d",   # tratamiento efectivo
               "w1",  # covariable predeterminada continua
               "w2")  # covariable predeterminada binaria

# Función auxiliar: t-test para cada variable
tabla_t <- function(data) {
  map_dfr(vars_desc, function(var) {
    x0 <- data[[var]][data$z == 0]
    x1 <- data[[var]][data$z == 1]
    tt <- t.test(x1, x0, var.equal = FALSE)
    tibble(
      Variable  = var,
      Media_Z0  = round(mean(x0, na.rm = TRUE), 3),
      Media_Z1  = round(mean(x1, na.rm = TRUE), 3),
      Diferencia = round(tt$estimate[1] - tt$estimate[2], 3),
      p_valor   = round(tt$p.value, 3),
      n_Z0      = sum(!is.na(x0)),
      n_Z1      = sum(!is.na(x1))
    )
  })
}

# Panel A: muestra completa
cat("\n--- Tabla 1A. Balance — muestra completa ---\n")
tabla1a <- tabla_t(df)
print(tabla1a)

# Panel B: muestra restringida al ancho de banda h* (CCT)
#   Nota: usamos el h* que se obtiene abajo en la primera etapa.
#   Por ahora estimamos preliminarmente con h = 0.5 (aprox.).
bw_prelim <- 0.50
cat(sprintf("\n--- Tabla 1B. Balance — muestra restringida |x| <= %.2f ---\n",
            bw_prelim))
tabla1b <- df %>% filter(abs(x) <= bw_prelim) %>% tabla_t()
print(tabla1b)
# Interpretación: w1 y w2 no deben tener diferencias significativas
# entre Z=0 y Z=1. Si las tienen, el supuesto de continuidad es
# cuestionable. El outcome y y el tratamiento d sí pueden diferir.


# ============================================================
# TABLA 2: PRIMERA ETAPA — rdrobust(d ~ x)
# ============================================================
# Estimamos el salto en Pr(D = 1 | X) con el ancho de banda CCT
# óptimo y con h*/2 y 2h* para evaluar sensibilidad.

cat("\n--- Tabla 2. Primera etapa: bandwidth óptimo h* ---\n")
fs_h <- rdrobust(y = df$d, x = df$x, c = 0, p = 1,
                 kernel = "triangular", bwselect = "mserd")
summary(fs_h)
h_star <- fs_h$bws[1, 1]
cat(sprintf("h* CCT = %.3f\n", h_star))

cat("\n--- Tabla 2. Primera etapa: bandwidth h*/2 ---\n")
fs_half <- rdrobust(y = df$d, x = df$x, c = 0, p = 1,
                    h = h_star / 2)
summary(fs_half)

cat("\n--- Tabla 2. Primera etapa: bandwidth 2h* ---\n")
fs_double <- rdrobust(y = df$d, x = df$x, c = 0, p = 1,
                      h = 2 * h_star)
summary(fs_double)
# Interpretación: el salto en Pr(D=1) debe ser sustancial y estable
# entre anchos de banda. Un salto pequeño (instrumento débil) infla
# los intervalos de confianza del estimador Fuzzy — análogo a F < 10
# en IV estándar.


# ============================================================
# TABLA 3: FORMA REDUCIDA (ITT) vs. FUZZY RD (LATE)
# ============================================================
# Verificamos la identidad Wald local:
#     τ_FRD  =  ITT  /  ΔPr(D=1)

cat("\n--- Tabla 3A. Forma reducida (ITT): rdrobust(y ~ x) ---\n")
rf <- rdrobust(y = df$y, x = df$x, c = 0, p = 1,
               kernel = "triangular", bwselect = "mserd")
summary(rf)

cat("\n--- Tabla 3B. Fuzzy RD (LATE): rdrobust(y ~ x, fuzzy = d) ---\n")
fuzzy <- rdrobust(y = df$y, x = df$x, c = 0, p = 1,
                  fuzzy = df$d,
                  kernel = "triangular", bwselect = "mserd")
summary(fuzzy)

# Verificación manual del estimador Wald
itt      <- rf$coef[1, 1]
delta_pr <- fs_h$coef[1, 1]
wald_mano <- itt / delta_pr
cat(sprintf(
  "\nVerificación Wald local:\n  ITT           = %.4f\n  Primera etapa = %.4f\n  ITT / ΔPr     = %.4f\n  τ_FRD (rdrobust) = %.4f\n",
  itt, delta_pr, wald_mano, fuzzy$coef[1, 1]
))
# Interpretación: τ_FRD ≈ ITT / ΔPr. La pequeña diferencia puede deberse
# a que rdrobust selecciona anchos de banda distintos para numerador y
# denominador en el modo fuzzy. El τ verdadero en la simulación es 0.60.


# ============================================================
# VALIDACIÓN (A): PRUEBA McCRARY — DENSIDAD DE LA RUNNING
# ============================================================
# H0: la densidad de X es continua en c = 0.
# Si los estudiantes pudieran manipular su puntaje exactamente
# al nivel de c_s, la densidad saltaría en el umbral, lo que
# invalidaría el supuesto de continuidad.

cat("\n--- Validación (A). McCrary density test (rddensity) ---\n")
mcc <- rddensity(X = df$x, c = 0)
summary(mcc)

rdplotdensity(rdd    = mcc,
              X      = df$x,
              title  = "Validación (A). Densidad de la running variable en el umbral",
              xlabel = "X (puntaje − cutoff)")
# Interpretación: un p-valor alto (no rechazamos H0) indica que no
# hay evidencia de manipulación — el diseño es creíble.


# ============================================================
# VALIDACIÓN (B): CUTOFFS PLACEBO
# ============================================================
# Estimamos el Fuzzy RD en puntos donde NO existe un umbral real
# (c = −0.3 y c = +0.3). Esperamos efectos cercanos a cero y no
# significativos.

for (c_falso in c(-0.3, 0.3)) {
  cat(sprintf("\n--- Validación (B). Placebo Fuzzy RD en c = %.2f ---\n",
              c_falso))
  placebo <- rdrobust(y = df$y, x = df$x,
                      c = c_falso, p = 1,
                      fuzzy = df$d)
  summary(placebo)
}
# Interpretación: efectos significativos en los umbrales falsos
# indicarían que el diseño captura algo distinto al umbral real
# (p. ej., una tendencia local en Y).


# ============================================================
# VALIDACIÓN (C): MATRIZ DE SENSIBILIDAD
#   filas    : h*/2,  h*,  2h*
#   columnas : p = 1, p = 2
# ============================================================
# Si el estimador cambia drásticamente con h o p, el resultado
# no es robusto. Reportamos el estimador robusto (bias-corrected)
# en cada celda.

h_grid <- c(h_star / 2, h_star, 2 * h_star)
p_grid <- c(1, 2)

mat <- expand_grid(h = h_grid, p = p_grid) %>%
  mutate(tau_robusto = NA_real_,
         se_robusto  = NA_real_,
         n_efectivo  = NA_integer_)

for (i in seq_len(nrow(mat))) {
  est <- tryCatch(
    rdrobust(y = df$y, x = df$x, c = 0,
             p     = mat$p[i],
             h     = mat$h[i],
             fuzzy = df$d),
    error = function(e) NULL
  )
  if (!is.null(est)) {
    mat$tau_robusto[i] <- est$coef[3, 1]   # bias-corrected robusto
    mat$se_robusto[i]  <- est$se[3, 1]
    mat$n_efectivo[i]  <- est$N_h[1] + est$N_h[2]
  }
}

cat("\n--- Validación (C). Matriz de sensibilidad (τ_FRD robusto) ---\n")
print(
  mat %>%
    mutate(h_label = case_when(
      round(h, 4) == round(h_star / 2, 4) ~ "h*/2",
      round(h, 4) == round(h_star,     4) ~ "h*",
      TRUE                                ~ "2h*"
    )) %>%
    select(h_label, p, tau_robusto, se_robusto, n_efectivo) %>%
    mutate(across(c(tau_robusto, se_robusto), ~ round(.x, 3)))
)
# Interpretación: si los coeficientes de la diagonal son similares
# (variación < 20%), el resultado es robusto al ancho de banda y al
# grado del polinomio. τ_verdadero = 0.60.


# ============================================================
# CIERRE — Preguntas de discusión
# ============================================================
# 1. ¿Cuánto vale el salto en la primera etapa? ¿Es el instrumento
#    fuerte o débil comparado con la regla de F > 10 en IV estándar?
# 2. ¿Cuánto vale el ITT en el umbral?
# 3. ¿Cuál es el LATE estimado? ¿Qué tan cerca está del τ verdadero (0.60)?
# 4. ¿Pasan las validaciones? ¿Qué concluiría si el test McCrary
#    fuera significativo?
# 5. ¿Qué pasa si reducen artificialmente el salto en la primera etapa?
#    (Modifiquen las probabilidades p_lo y p_hi en el generador de datos
#    y vuelvan a estimar — observen cómo crecen los IC del LATE.)
# ============================================================
