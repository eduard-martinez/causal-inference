# ============================================================
# Ludwig & Miller (2007) — Script de replicación
# ECO-60116: Inferencia, Causalidad y Políticas Públicas
# Universidad Icesi — Eduard F. Martinez Gonzalez, Ph.D.
#
# Resultados principales que se replican:
#   Figura 1 : Gráfico RD — discontinuidad en mortalidad
#              infantil (5–9 años, causas Head Start) alrededor
#              del umbral de pobreza.
#   Tabla 1  : Estimaciones RD del efecto sobre el gasto/
#              participación en Head Start (primera etapa).
#   Tabla 2  : Estimaciones RD del efecto sobre mortalidad
#              infantil (5–9 años) — resultado principal.
#   Tabla 3  : Efectos sobre resultados educativos (censo 1990).
#   Placebo  : Mortalidad por causas NO relacionadas con
#              Head Start (lesiones) y mortalidad pre-programa.
#   Tabla 4  : Estadísticas descriptivas por lado del umbral.
# ============================================================

# ------------------------------------------------------------
# 0. Setup
# ------------------------------------------------------------
rm(list = ls())

# Paquetes
library(RDHonest)      # datos de RD
library(tidyverse)     # manipulación de datos y ggplot2
library(rdrobust)      # rdrobust(), rdplot(), rdbwselect()
library(rddensity)     # rddensity() — prueba de manipulación McCrary
library(modelsummary)  # tablas de resultados

# Cargar datos
df <- RDHonest::headst

# Variable de asignación (running variable): tasa de pobreza 1960 (%)
# Umbral: condado 300 más pobre ≈ 59.1984 (se centra en 0)

## veamos la runnig variable centrada en el umbral
plot(density(df$povrate))

## creamos la variable de tratamiento
df <- mutate(df, treated = as.integer(povrate >= 0))
table(df$treated)

## salto en la probabilidad de ser tratado
plot(df$povrate , df$treated)

# ============================================================
# FIGURA 1: Gráfico RD — discontinuidad visual en mortalidad
# ============================================================
# Mortalidad (5–9 años) por causas cubiertas por Head Start, 1973–1983.
# Una discontinuidad visual en el umbral es la primera evidencia
# de un efecto causal del programa.

rdplot(y = df$mortHS,
       x = df$povrate,
       c = 0,
       nbins = c(20, 20), # bins a cada lado del umbral
       p = 3, # polinomio local de grado 4 (como en el paper)
       title = "Figura 1. Discontinuidad en mortalidad infantil (5–9 años) en el umbral OEO",
       x.label = "Tasa de pobreza 1960 (centrada en el umbral)",
       y.label = "Mortalidad por causas Head Start, 1973–1983 (por 100.000)"
)
# Interpretación: Se espera un salto negativo en el umbral — los condados
# que recibieron asistencia técnica (tratados) muestran menor mortalidad.

# ============================================================
# TABLA 2: Resultado principal — efecto sobre mortalidad
#          infantil (5–9 años) por causas Head Start
# ============================================================
# Estimaciones RD con distintos grados de polinomio local.
# El paper original usa principalmente grado 4.
# Kernel triangular y ancho de banda MSE-óptimo.

# Especificación 1: polinomio local grado 1 (lineal)
rd_p1 <- rdrobust(y = df$mortHS,
                  x = df$povrate,
                  c = 0,
                  p = 1,
                  kernel = "triangular",
                  bwselect = "mserd")

# Especificación 2: polinomio local grado 2 (cuadrático)
rd_p2 <- rdrobust(y = df$mortHS,
                  x = df$povrate,
                  c = 0,
                  p = 2,
                  kernel = "triangular",
                  bwselect = "mserd")

# Especificación 3: polinomio local grado 4 (como en el paper)
rd_p4 <- rdrobust(y = df$mortHS,
                  x = df$povrate,
                  c = 0,
                  p = 4,
                  kernel = "triangular",
                  bwselect = "mserd")

# print
rd_p1
rd_p1$coef
summary(rd_p1)

# print
summary(rd_p2)

# print
summary(rd_p4)

# ============================================================
# TABLA 3: Efectos sobre resultados educativos (censo 1990)
# ============================================================
# hs90: tasa de graduación de bachillerato en 1990 (edades 18–24).
# Identifica efectos de largo plazo de Head Start sobre capital
# humano — la cohorte expuesta al programa debería tener mayor
# probabilidad de completar el bachillerato.

rd_hs90_p1 <- rdrobust(y = df$hs90,
                       x = df$povrate,
                       c = 0,
                       p = 1,
                       kernel = "triangular",
                       bwselect = "mserd")

rd_hs90_p4 <- rdrobust(y = df$hs90,
                       x = df$povrate,
                       c = 0,
                       p = 4,
                       kernel = "triangular",
                       bwselect = "mserd")

summary(rd_hs90_p1)
summary(rd_hs90_p4)

# ============================================================
# PRUEBAS DE VALIDEZ DEL DISEÑO RD
# ============================================================

# --- (A) Prueba de manipulación de McCrary ---
# Si los condados manipularon su tasa de pobreza para cruzar el
# umbral, habría un salto en la densidad del running variable,
# lo que invalidaría el supuesto de continuidad del diseño RD.

## test McCrary
mccrary <- rddensity(X = df$povrate, c = 0)
summary(mccrary)

## plot
rdplotdensity(mccrary,
              X = df$povrate,
              title  = "Prueba de McCrary: Densidad del running variable en el umbral",
              xlabel = "Tasa de pobreza 1960 relativa al umbral")

# --- (B) Prueba placebo — mortalidad por lesiones ---
# mortInj: mortalidad (5–9 años) por lesiones, 1973–1983.
# Las lesiones NO son una causa cubierta por Head Start.
# Si hubiera un salto significativo aquí, indicaría que el umbral
# afecta algo más que el acceso a Head Start (problema de validez
# interna).

# estimation
rd_placebo <- rdrobust(y = df$mortInj,
                       x = df$povrate,
                       c = 0,
                       p = 4,
                       kernel   = "triangular",
                       bwselect = "mserd")
summary(rd_placebo)

# --- (C) t-test por lado del umbral
# Compara las medias de los outcomes y covariables clave a cada
# lado del umbral. Sirve como diagnóstico informal de la
# continuidad de las covariables predeterminadas (línea de base).

# Dos paneles:
#   Panel A — muestra completa (todo el soporte)
#   Panel B — muestra restringida cerca al corte (|povrate| <= bw)
vars_desc <- c("mortHS",    # outcome principal
               "mortInj",   # placebo: lesiones
               "hs90",      # resultado educativo largo plazo
               "black",     # covariable: % negro
               "urban",     # covariable: % urbano
               "pop")       # covariable: población

# Ancho de banda que usa el paper
bw <- 6

# Función auxiliar: t-test para una variable dado un dataframe
tabla_t <- function(data) {
           map_dfr(vars_desc, function(var) {
                   x0 <- data[[var]][data$treated == 0]
                   x1 <- data[[var]][data$treated == 1]
                   tt <- t.test(x1, x0, var.equal = FALSE)
                   
                   tibble(Variable = var,
                          Control = round(mean(x0, na.rm = TRUE), 2),
                          Treated = round(mean(x1, na.rm = TRUE), 2),
                          Diff    = round(tt$estimate[1] - tt$estimate[2], 2),
                          p_value       = round(tt$p.value, 3),
                          n_control     = sum(!is.na(x0)),
                          n_trated    = sum(!is.na(x1))
                          )
          })}

# Panel A: muestra completa
tabla1a <- tabla_t(df)
tabla1a

# Panel B: muestra restringida al ancho de banda óptimo
tabla1b <- filter(df , abs(povrate) <= bw) %>% tabla_t()
tabla1b

# Interpretación: si el diseño RD es válido, las covariables de
# 1960 (black, urban, pop) deben ser similares a ambos lados del
# umbral — no deben mostrar discontinuidades.

