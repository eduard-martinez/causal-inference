# ============================================================
# Camacho & Mejía (2017) — Simulación Panel y Efectos Fijos
# ECO-60116: Inferencia, Causalidad y Políticas Públicas
# Universidad Icesi — Eduard F. Martinez Gonzalez, Ph.D.
#
# Datos: panel sintético que imita la estructura de Camacho &
# Mejía (2017). Lo genera 'generate_data_panel_fe.R' (correr
# ese script primero para producir simulacion_panel_fe.csv).
# Como los microdatos RIPS son restringidos, esta base es el
# sustituto ejecutable. El efecto verdadero es beta = 2.0.
#
# Variables:
# id : identificador del individuo
# mun  : municipio de residencia (nivel de variación del tratamiento)
# t  : periodo (1..5)
# s  : intensidad de aspersión del municipio (tratamiento)
# coca : control que varía en el tiempo (hectáreas de coca)
# y  : outcome (índice de salud)
# u  : heterogeneidad fija NO observada (en la base solo con
#    fines didácticos; NINGÚN modelo la usa)
#
# Lo que se ilustra:
# Modelo 1   : OLS pooled — SESGADO (ignora u_i)
# Modelo 2   : FE de unidad (within) — recupera beta
# Modelo 3   : Two-way FE (tipo C&M) + SE clusterizados por mun
# Verificación : transformación within manual ≡ feols(... | id)
# Inferencia : SE naive vs. HC1 vs. cluster por id vs. por mun
# Figura   : datos crudos vs. centrados (variación within)
# ============================================================

# ------------------------------------------------------------
# 0. Setup
# ------------------------------------------------------------
rm(list = ls())
library(tidyverse)   # manipulación de datos y ggplot2
library(fixest)    # feols(): efectos fijos + SE clusterizados

# Cargar datos
df <- read_csv("simulacion_panel_fe.csv", show_col_types = FALSE)
beta_true <- 2.0   # beta verdadero incorporado en el DGP

## head
head(df)

## Descomposición de la varianza del tratamiento: within vs. between
# El estimador FE solo usa la varianza WITHIN. Si casi toda la varianza
# de s fuera between, beta_FE tendría una varianza enorme.
df <- df %>% group_by(id) %>% mutate(s_bar=mean(s)) %>% ungroup()

## var s
var_s <- c(total=var(df$s) , between=var(df$s_bar) , within=var(df$s - df$s_bar))
round(var_s, 3)


# ============================================================
# MODELO 1: OLS POOLED (SESGADO)
# ============================================================
# Trata el panel como una cross-section: u_i queda en el residual y
# está correlacionado con s -> sesgo por variable omitida.
# El canal del sesgo es municipal: los municipios con peor salud basal
# (a_m alto) reciben más aspersión, y u_i hereda ese a_m. Por eso
# Cov(s, u) > 0 y el coeficiente de s queda por ENCIMA de beta = 2.
m1_pooled <- feols(y ~ s + coca, data = df)
summary(m1_pooled)


# ============================================================
# MODELO 2: FE DE UNIDAD (WITHIN)
# ============================================================
# Absorbe u_i; identifica beta con la variación dentro de cada individuo.
# El coeficiente de s regresa a ≈ 2: la transformación within eliminó
# la heterogeneidad fija que causaba el sesgo.
m2_fe <- feols(y ~ s + coca | id, data = df)
summary(m2_fe)


# ============================================================
# MODELO 3: TWO-WAY FE (TIPO C&M) + SE CLUSTERIZADOS POR MUNICIPIO
# ============================================================
# Absorbe individuo y tiempo. El tratamiento varía a nivel MUNICIPIO-
# tiempo, así que agrupamos los errores por municipio: ese es el nivel
# de variación del tratamiento, NO el individuo (regla de C&M).
m3_twfe <- feols(y ~ s + coca | id + t, cluster = ~ mun, data = df)
summary(m3_twfe)

## Tabla comparativa (etable, nativa de fixest)
# Solo (2) y (3) recuperan beta; el pooled está sesgado al alza.
etable(m1_pooled, m2_fe, m3_twfe, dict=c(s = "Aspersión", coca = "Coca") , digits = 3)


# ============================================================
# VERIFICACIÓN: transformación within manual ≡ feols(... | id)
# ============================================================
# Centramos cada variable restándole la media de su propia unidad
# (transformación within) y corremos OLS sobre las variables centradas.
# El coeficiente es idéntico al del Modelo 2; los SE difieren porque el
# OLS manual no corrige los grados de libertad por los N efectos fijos
# absorbidos, mientras que feols(... | id) sí lo hace.
df_w <- df %>%
        group_by(id) %>%
        mutate(y_w = y - mean(y),
               s_w = s - mean(s),
               coca_w = coca - mean(coca)) %>%
        ungroup()

m_within <- feols(y_w ~ s_w + coca_w - 1, data = df_w) # sin intercepto

equivalencia <- c("feols(|id)" = coef(m2_fe)["s"], "within manual" = coef(m_within)["s_w"])
round(equivalencia, 6)


# ============================================================
# INFERENCIA: SE naive vs. HC1 vs. cluster por id vs. cluster por mun
# ============================================================
# Dos fuentes de correlación de los residuales: (i) el error tiene
# correlación serial AR1 dentro del individuo, y (ii) el tratamiento s
# es COMÚN a todos los individuos del mismo municipio en cada periodo.
# La fuente (ii) domina: los residuales se parecen sobre todo dentro del
# municipio. Por eso clusterizar por id apenas mueve el SE, mientras que
# clusterizar por MUNICIPIO —el nivel de variación del tratamiento— lo
# aumenta de forma notoria. Reportar el naive o el de id declararía
# significancia espuria (el punto de BDM, 2004). Con M = 50 municipios,
# G = 50 supera la regla de pulgar de 30-40 clusters.
se <- c(iid = summary(m2_fe, vcov = "iid")$coeftable["s", "Std. Error"],
        hc1 = summary(m2_fe, vcov = "hetero")$coeftable["s", "Std. Error"],
        cluster_id  = summary(m2_fe, vcov = ~ id)$coeftable["s", "Std. Error"],
        cluster_mun = summary(m2_fe, vcov = ~ mun)$coeftable["s", "Std. Error"])
round(se, 4)
round(se / se["iid"], 2) # cada SE relativo al naive


# ============================================================
# FIGURA: datos crudos vs. centrados (la transformación within)
# ============================================================
# Misma imagen que en las slides: a la izquierda los datos crudos, donde
# las nubes de cada individuo están desplazadas por su u_i (variación
# between) y la nube agregada engaña; a la derecha los datos centrados,
# donde aparece la pendiente común WITHIN que estima el FE.
set.seed(1)
sub <- df %>%
       filter(id %in% sample(unique(df$id), 12)) %>%
       group_by(id) %>%
       mutate(s_w = s - mean(s) , y_w = y - mean(y)) %>%
       ungroup()

# Apilamos crudos y centrados en formato largo, con una etiqueta de panel.
# Así un solo ggplot dibuja los dos paneles con facet_wrap (sin patchwork).
sub_largo <- bind_rows(sub %>% transmute(id, panel = "1. Datos crudos", sx = s, yy = y),
                       sub %>% transmute(id, panel = "2. Datos centrados (within)", sx = s_w, yy = y_w))
sub_largo

## plot
fig <- ggplot(sub_largo, aes(sx, yy)) +
       geom_smooth(aes(group = id, color = factor(id)),
           method = "lm", se = FALSE, linewidth = 0.4) +
       geom_point(aes(color = factor(id)), alpha = 0.7) +
       geom_smooth(method = "lm", se = FALSE, color = "black", linewidth = 0.8) +
       facet_wrap(~ panel, scales = "free") +
       labs(title  = "Qué hace la transformación within",
            subtitle = "Cada color es un individuo seguido en el tiempo. FE descarta la variación entre unidades y usa solo la de dentro de cada unidad.",
            x = "Aspersión", y = "Outcome") +
       theme_minimal() + theme(legend.position = "none")
fig

# ============================================================
# CIERRE — Preguntas de discusión
# ============================================================
# 1. ¿Cuánto se aleja el coeficiente del pooled respecto a beta = 2?
#  ¿En qué dirección, y por qué (signo de Cov(s, u))?
# 2. ¿Recuperan beta los modelos 2 y 3? ¿Coinciden entre sí? ¿Por qué?
# 3. ¿Por qué el coeficiente del within manual es idéntico al de
#  feols(|id) pero los SE no?
# 4. Compara los cuatro SE. ¿Por qué clusterizar por id casi no cambia
#  nada, pero clusterizar por municipio sí? ¿Qué dice eso sobre "a qué
#  nivel agrupar"?
# 5. Bajen la varianza del tratamiento en el generador: reduzcan la sd
#  del rnorm(M * Tt, 0, 1) que construye s_{m,t} y vuelvan a estimar.
#  Observen cómo crece el SE de beta_FE: es el costo de depender solo
#  de la variación intra-municipio del tratamiento.
# ============================================================
